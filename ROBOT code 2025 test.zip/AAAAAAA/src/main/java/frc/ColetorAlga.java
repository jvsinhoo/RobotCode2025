// package frc;

// // Copyright (c) FIRST and other WPILib contributors.
// // Open Source Software; you can modify and/or share it under the terms of
// // the WPILib BSD license file in the root directory of this project.

// import com.revrobotics.spark.SparkLowLevel.MotorType;

// import java.util.logging.Level;

// import com.revrobotics.spark.SparkMax;

// import edu.wpi.first.math.controller.ElevatorFeedforward;
// import edu.wpi.first.math.controller.ProfiledPIDController;
// import edu.wpi.first.math.trajectory.TrapezoidProfile;
// import edu.wpi.first.wpilibj.Encoder;
// import edu.wpi.first.wpilibj.Joystick;
// import edu.wpi.first.wpilibj.TimedRobot;
// import edu.wpi.first.wpilibj.motorcontrol.PWMSparkMax;
// import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
// import edu.wpi.first.wpilibj2.command.Command;
// import edu.wpi.first.wpilibj2.command.SubsystemBase;


// import com.revrobotics.spark.SparkLowLevel.MotorType;
// import com.revrobotics.spark.SparkMax;

// import edu.wpi.first.wpilibj.XboxController;
// import edu.wpi.first.wpilibj2.command.SubsystemBase;

// @SuppressWarnings("PMD.RedundantFieldInitializer")
// public class ColetorAlga extends SubsystemBase {
 


// private final SparkMax spark9 = new SparkMax(9, MotorType.kBrushed);
// private final XboxController xboxAlga = new XboxController(1);


//     if (xboxAlga.getBButton()) { // O método getBButton() verifica o botão B
//         spark9.set(1.0); // Liga o motor 1 com 100% de potência
//       } else {
//         spark9.set(0.0); // Desliga o motor 2
//       }
// }


  
